"use client";

import React from "react";

//Example : Functional Component
export default function Person() {
  return (
    <div>
      <h1>I am Function Component.</h1>
    </div>
  );
}
