"use client";

import React from "react";

//Example : Class Component
export default class Person extends React.Component {
  render() {
    return (
      <div>
        <h1>I am Class Component</h1>
      </div>
      
    );
  }
}
