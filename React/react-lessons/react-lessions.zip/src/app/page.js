import Example24 from "../components/Example24";
export default function Home() {
  return (
    <div>
      <Example24 />
    </div>
  );
}
